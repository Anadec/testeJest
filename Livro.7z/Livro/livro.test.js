const {Livro, adicionarLivro, livros, removerLivro, buscarLivro} = require('./livro')

test('Adicionar novo livro', () =>{
    const livro = new Livro('A pedra Filosofal', 'JK Rowling', 2001)
    adicionarLivro(livro)
    expect(livros).toContain(livro)
}
)
test('Remover pelo titulo', () => {
    const livro = new Livro('A pedra Filosofal', 'JK Rowling', 2001)
    adicionarLivro(livro)
    removerLivro('A pedra Filosofal')
    expect('Livro removido')
})

test('Buscar pelo titulo', () => {
    const livro = new Livro('A pedra Filosofal', 'JK Rowling', 2001)
    adicionarLivro(livro)
    removerLivro('A pedra Filosofal')
    buscarLivro('A pedra Filosofal')
    expect('Busca um livro pelo titulo')
})